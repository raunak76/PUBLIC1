"""Development-only integration test for smaller public-data fixtures."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
import pandas as pd

root=Path(__file__).resolve().parent
fixture=root/'small_fixture'
fixture.mkdir(exist_ok=True)
train=pd.read_csv(root.parent/'data/train_rain.csv',dtype={'location_id':str}).sample(n=120,random_state=9305)
test=pd.read_csv(root.parent/'data/test.csv',dtype={'location_id':str}).head(5)
train.to_csv(fixture/'train_rain.csv',index=False)
test.to_csv(fixture/'test.csv',index=False)
output=fixture/'working/submission.csv'
start=time.perf_counter()
cmd=[sys.executable,str(root/'solution.py'),str(fixture),str(output)]
done=subprocess.run(cmd,cwd=fixture,text=True,capture_output=True,timeout=600)
elapsed=time.perf_counter()-start
print(done.stdout,flush=True)
if done.returncode:raise RuntimeError(done.stderr)
sub=pd.read_csv(output,dtype=str)
targets=['continent','geographic_zone','primary_land_type','secondary_land_type']
assert list(sub.columns)==['location_id']+targets and sub.shape==(5,5)
assert sub.location_id.equals(test.location_id) and not sub.isna().any().any()
for c in targets:assert sub[c].isin(train[c]).all()
(root/'small_fixture_result.json').write_text(json.dumps({'train_rows':120,'test_rows':5,'exit_code':done.returncode,'seconds':elapsed,'id_order_preserved':True,'schema_valid':True,'legal_labels':True},indent=2))
print('Small-fixture integration test passed.',flush=True)
