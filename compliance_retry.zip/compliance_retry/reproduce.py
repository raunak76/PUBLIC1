"""Development-only fresh-process reproduction and resource measurement."""
import hashlib,json,shutil,subprocess,sys,time
from pathlib import Path
import psutil

ROOT=Path(__file__).resolve().parent
fresh=ROOT/'reproduction'
public=fresh/'public'
public.mkdir(parents=True,exist_ok=True)
for name in ['train_rain.csv','test.csv','sample_submission.csv']:
    shutil.copy2(ROOT.parent/'data'/name,public/name)
evidence=[]
for name in ['first','second']:
    run=fresh/name
    if run.exists(): raise RuntimeError(f'Reproduction directory already exists: {run}')
    run.mkdir(parents=True)
    shutil.copy2(ROOT/'solution.py',run/'solution.py')
    output=run/'working/submission.csv'
    command=[sys.executable,'-u','solution.py',str(public.resolve()),str(output.resolve())]
    started=time.perf_counter()
    with (run/'execution.log').open('w',encoding='utf-8') as log:
        process=subprocess.Popen(command,cwd=run,stdout=log,stderr=subprocess.STDOUT)
        top=psutil.Process(process.pid)
        peak=0
        while process.poll() is None:
            try:
                processes=[top]+top.children(recursive=True)
                used=0
                for p in processes:
                    try:
                        info=p.memory_info();used+=getattr(info,'peak_wset',info.rss)
                    except psutil.Error: pass
                peak=max(peak,used)
            except psutil.Error:pass
            if time.perf_counter()-started>3500:
                for child in top.children(recursive=True):child.terminate()
                process.terminate();raise RuntimeError('Runtime exceeded safety budget')
            time.sleep(.25)
        code=process.wait()
    elapsed=time.perf_counter()-started
    print((run/'execution.log').read_text(),flush=True)
    if code:raise RuntimeError(f'Fresh execution failed: {code}')
    digest=hashlib.sha256(output.read_bytes()).hexdigest()
    item={'run':name,'command':command,'cwd':str(run.resolve()),'exit_code':code,'wall_seconds_including_imports':elapsed,'peak_process_tree_working_set_mib':peak/1024**2,'submission_sha256':digest,'script_sha256':hashlib.sha256((run/'solution.py').read_bytes()).hexdigest()}
    evidence.append(item)
    (ROOT/'reproduction.json').write_text(json.dumps(evidence,indent=2))
    print('FRESH RUN',json.dumps(item),flush=True)
    if name=='first':shutil.copy2(output,ROOT/'submission.csv')
    else:assert output.read_bytes()==(ROOT/'submission.csv').read_bytes(), 'Reproduction differs'
print('Two fresh executions succeeded and CSV bytes match.',flush=True)

