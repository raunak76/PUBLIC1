"""Recover geographic metadata from public rainfall, using CPU SVMs trained from scratch.

Usage: python solution.py PUBLIC_DIRECTORY OUTPUT_CSV
"""
import os
os.environ['OMP_NUM_THREADS'] = '2'
os.environ['OPENBLAS_NUM_THREADS'] = '2'
os.environ['MKL_NUM_THREADS'] = '2'
import sys
import time
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.svm import SVC
from sklearn.utils.class_weight import compute_sample_weight

TARGETS = ['continent', 'geographic_zone', 'primary_land_type', 'secondary_land_type']
CONFIG = {'continent': {'view': 'log', 'alpha': 0.5, 'C': 10.0, 'gamma': 1.0, 'power': 0.0}, 'geographic_zone': {'view': 'shape', 'alpha': 0.75, 'C': 3.0, 'gamma': 1.0, 'power': 0.0}, 'primary_land_type': {'view': 'log', 'alpha': 0.75, 'C': 3.0, 'gamma': 1.0, 'power': 0.0}, 'secondary_land_type': {'view': 'log', 'alpha': 0.75, 'C': 3.0, 'gamma': 1.0, 'power': 0.25}}

def features(df):
    cols = [c for c in df.columns if len(c)==10 and c[4]=='-' and c[7]=='-']
    dates = pd.to_datetime(cols)
    a = df[cols].to_numpy(dtype=float)
    n = len(a)
    out = {}
    def add(name, x): out[name] = x
    def stats(v, prefix, full=False):
        valid = np.isfinite(v)
        den = np.maximum(valid.sum(1),1)
        avg = np.nanmean(v,axis=1)
        std = np.nanstd(v,axis=1)
        add(prefix+'mean',avg); add(prefix+'std',std)
        add(prefix+'cv',std/(avg+.01))
        for t in ([0,.1,1,5,10,20,50] if full else [0,1,10]):
            add(prefix+f'frac_gt{t}',((v>t)&valid).sum(1)/den)
        for q in ([.1,.25,.5,.75,.9,.95,.99,1] if full else [.5,.9]):
            add(prefix+f'q{q}',np.nanquantile(v,q,axis=1))
        positive = np.where(v>0,v,np.nan)
        add(prefix+'wet_mean',np.nanmean(positive,axis=1))
        add(prefix+'log_mean',np.nanmean(np.log1p(v),axis=1))
        if full:
            add(prefix+'log_std',np.nanstd(np.log1p(v),axis=1))
            add(prefix+'wet_std',np.nanstd(positive,axis=1))
            add(prefix+'wet_log_mean',np.nanmean(np.log(positive),axis=1))
            add(prefix+'wet_log_std',np.nanstd(np.log(positive),axis=1))
            z=(v-avg[:,None])/(std[:,None]+1e-8)
            add(prefix+'skew',np.nanmean(z**3,axis=1))
            add(prefix+'kurtosis',np.nanmean(z**4,axis=1))
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', RuntimeWarning)
        stats(a,'global_',True)
        for m in range(1,13): stats(a[:,dates.month==m],f'm{m}_')
        for year in np.unique(dates.year):
            v=a[:,dates.year==year]
            stats(v,f'y{year}_')
        for i in range(0,a.shape[1],30):
            v=a[:,i:i+30]
            add(f'block{i}_mean',np.nanmean(v,axis=1))
            add(f'block{i}_wet',np.nanmean(np.where(np.isnan(v),np.nan,v>0),axis=1))
        means=np.column_stack([out[f'm{m}_mean'] for m in range(1,13)])
        add('season_maxmin',means.max(1)-means.min(1))
        add('season_ratio',means.max(1)/(means.min(1)+.01))
        add('season_std',means.std(1))
        for m in range(12): add(f'm{m+1}_share',means[:,m]/(means.sum(1)+.01))
        for kind,v in [('raw',a),('log',np.log1p(a)),('wet',np.where(np.isnan(a),np.nan,a>0))]:
            center=np.nanmean(v,axis=1)
            clean=np.where(np.isfinite(v),v,center[:,None])
            z=clean-center[:,None]
            variance=np.mean(z*z,axis=1)
            for lag in [1,2,3,7,14,30,60,90,180,365]:
                add(f'{kind}_corr{lag}',np.mean(z[:,:-lag]*z[:,lag:],axis=1)/(variance+1e-8))
            t=np.arange(a.shape[1])
            for h in range(1,7):
                phase=2*np.pi*t/365.25*h
                co=(z*np.cos(phase)).mean(1)
                si=(z*np.sin(phase)).mean(1)
                add(f'{kind}_cos{h}',co); add(f'{kind}_sin{h}',si)
                add(f'{kind}_amp{h}',np.hypot(co,si))
            for window in [7,30,90]:
                cs=np.cumsum(np.column_stack([np.zeros(n),clean]),axis=1)
                roll=(cs[:,window:]-cs[:,:-window])/window
                add(f'{kind}_roll{window}_min',roll.min(1)); add(f'{kind}_roll{window}_max',roll.max(1))
                add(f'{kind}_roll{window}_std',roll.std(1))
        for threshold in [0,1]:
            wet=np.where(np.isfinite(a),a>threshold,False)
            for state in [False,True]:
                lengths=[]
                for row in wet:
                    mask=row==state
                    edges=np.diff(np.r_[False,mask,False].astype(int))
                    runs=np.flatnonzero(edges==-1)-np.flatnonzero(edges==1)
                    lengths.append([runs.max(initial=0),np.mean(runs) if len(runs) else 0,np.quantile(runs,.9) if len(runs) else 0,len(runs)])
                for j,name in enumerate(['max','mean','q90','count']): add(f'run{threshold}_{state}_{name}',np.array(lengths)[:,j])
    return pd.DataFrame(out).replace([np.inf,-np.inf],np.nan).fillna(0)

def rainfall_views(frame):
    summary = features(frame).to_numpy(dtype=float)
    summary = np.sign(summary) * np.log1p(np.abs(summary))
    dates = [c for c in frame.columns if len(c) == 10 and c[4] == '-' and c[7] == '-']
    rain = frame[dates].to_numpy(dtype=float)
    # Imputation is independent for each location; test rows never affect fitting.
    count = np.isfinite(rain).sum(axis=1)
    mean = np.nansum(rain, axis=1) / np.maximum(count, 1)
    daily = np.log1p(np.where(np.isfinite(rain), rain, mean[:, None]))
    shape = (daily - daily.mean(axis=1, keepdims=True)) / (daily.std(axis=1, keepdims=True) + .01)
    return {'log': daily, 'shape': shape, 'summary': summary}


def fit_models(train_rainfall, train_targets):
    """Fit every scaler and classifier using released training rows only."""
    views = rainfall_views(train_rainfall)
    scalers = {}
    training_views = {}
    for name, values in views.items():
        scaler = StandardScaler().fit(values)
        scalers[name] = scaler
        training_views[name] = scaler.transform(values)

    training_kernels = {}
    models = {}
    for target in TARGETS:
        params = CONFIG[target]
        gamma = params['gamma']
        for name in [params['view'], 'summary']:
            if (name, gamma) not in training_kernels:
                values = training_views[name]
                training_kernels[name, gamma] = rbf_kernel(values, gamma=gamma / values.shape[1])
        alpha = params['alpha']
        kernel = (alpha * training_kernels[params['view'], gamma]
                  + (1.0 - alpha) * training_kernels['summary', gamma])
        model = SVC(C=params['C'], kernel='precomputed',
                    class_weight='balanced' if target == 'continent' else None,
                    cache_size=256, random_state=2026)
        sample_weight = np.ones(len(train_targets))
        if params['power']:
            sample_weight = compute_sample_weight('balanced', train_targets[target]) ** params['power']
            sample_weight /= sample_weight.mean()
        # The target stays as its original string Series; no manual encoding.
        model.fit(kernel, train_targets[target], sample_weight=sample_weight)
        models[target] = model
        print('Fitted on public training rows:', target, flush=True)
    return scalers, training_views, models


def predict_models(test_rainfall, fitted):
    """Transform test rainfall with training-fitted scalers, then predict strings."""
    scalers, training_views, models = fitted
    test_views = rainfall_views(test_rainfall)
    for name in test_views:
        test_views[name] = scalers[name].transform(test_views[name])
    prediction_kernels = {}
    predictions = pd.DataFrame(index=range(len(test_rainfall)))
    for target in TARGETS:
        params = CONFIG[target]
        gamma = params['gamma']
        for name in [params['view'], 'summary']:
            if (name, gamma) not in prediction_kernels:
                reference = training_views[name]
                prediction_kernels[name, gamma] = rbf_kernel(
                    test_views[name], reference, gamma=gamma / reference.shape[1])
        alpha = params['alpha']
        kernel = (alpha * prediction_kernels[params['view'], gamma]
                  + (1.0 - alpha) * prediction_kernels['summary', gamma])
        predictions[target] = models[target].predict(kernel)
    return predictions


def run(data_dir, output_path):
    started = time.perf_counter()
    np.random.seed(2026)
    data_dir = Path(data_dir).resolve()
    output_path = Path(output_path).resolve()
    # Only the named released training and test CSVs are dataset inputs.
    missing = [name for name in ['train_rain.csv', 'test.csv'] if not (data_dir / name).is_file()]
    if missing:
        raise FileNotFoundError(f'Missing {missing} in public directory {data_dir}')
    if output_path in [(data_dir / name).resolve() for name in ['train_rain.csv', 'test.csv', 'sample_submission.csv']]:
        raise ValueError('The output must not overwrite a public input file.')

    train = pd.read_csv(data_dir / 'train_rain.csv', dtype={'location_id': str})
    dates = [c for c in train.columns if len(c) == 10 and c[4] == '-' and c[7] == '-']
    if not dates or not len(train):
        raise ValueError('Training input must contain daily rainfall columns and labeled rows.')
    train_targets = train.loc[:, TARGETS].copy()
    for target in TARGETS:
        if train_targets[target].isna().any() or not train_targets[target].map(lambda value: isinstance(value, str)).all():
            raise ValueError(f'Training target {target} must contain original class strings.')
    train_rainfall = train.loc[:, dates].copy()
    fitted = fit_models(train_rainfall, train_targets)

    # Test data is first loaded after all learned objects have been fitted.
    test = pd.read_csv(data_dir / 'test.csv', dtype={'location_id': str})
    if list(test.columns) != ['location_id'] + dates:
        raise ValueError('Test must contain location_id and the same ordered rainfall dates as train.')
    if not len(test) or test.location_id.isna().any() or test.location_id.duplicated().any():
        raise ValueError('Test rows must have non-null, unique IDs.')
    prediction = predict_models(test.loc[:, dates], fitted)
    submission = pd.concat([test[['location_id']].reset_index(drop=True), prediction], axis=1)
    if len(submission) != len(test) or list(submission.columns) != ['location_id'] + TARGETS:
        raise ValueError('Invalid submission shape or schema.')
    if submission.isna().any().any() or not submission.location_id.equals(test.location_id):
        raise ValueError('Null output or changed test ID order.')
    for target in TARGETS:
        if not submission[target].isin(train_targets[target].unique()).all():
            raise ValueError(f'Prediction outside training class vocabulary: {target}')
    output_path.parent.mkdir(parents=True, exist_ok=True)
    submission.to_csv(output_path, index=False, lineterminator='\n')
    print(f'Wrote {len(submission)} rows to {output_path}', flush=True)
    print(f'Total CPU pipeline wall time: {time.perf_counter() - started:.3f} seconds', flush=True)


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: python solution.py PUBLIC_DIRECTORY OUTPUT_CSV')
    run(sys.argv[1], sys.argv[2])
