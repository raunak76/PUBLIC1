"""Same-episode specimen retrieval.

Usage: python solution.py <public_dir> <output_csv>

Fine-tunes publicly available DINOv2 encoders (timm / Hugging Face Hub weights) on the released
training cases with a within-gallery contrastive loss, embeds the evaluation images (three zoom views averaged), averages the
cosine-similarity matrices of the ensemble members inside each gallery, applies a Sinkhorn
row/column normalisation (a symmetric re-scoring of the pixel similarities) and ranks candidates.
"""
import sys, os, math, time, random
import numpy as np, pandas as pd, torch, torch.nn.functional as F, timm
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as T

PUBLIC = sys.argv[1]
OUT = sys.argv[2]
DEV = "cuda" if torch.cuda.is_available() else "cpu"
torch.set_num_threads(4)

# Ensemble members: (backbone, input height, input width, seed, TTA zoom scales).
# All weights are public timm / Hugging Face Hub checkpoints.
MEMBERS = [
    ("vit_small_patch14_dinov2.lvd142m", 518, 378, 0, (1.0, 0.85, 0.95, 1.05, 1.15)),
    ("vit_small_patch14_dinov2.lvd142m", 518, 378, 1, (1.0, 0.9, 1.1)),
    ("vit_small_patch14_dinov2.lvd142m", 392, 280, 0, (1.0, 0.9, 1.1)),
    ("vit_base_patch14_dinov2.lvd142m", 392, 280, 0, (1.0, 0.9, 1.1)),
]
EPOCHS, LR, WD, TEMP, LAYER_DECAY, GAL_PER_STEP, MAX_IMGS = 8, 2e-5, 0.05, 0.03, 0.8, 4, 64
# embedding = mean of L2-normalised features over the member's zoom views
SINKHORN_TEMP, SINKHORN_ITERS = 0.03, 20
MEAN, STD = (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)


def seed_all(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)


# Inputs are limited to the released public train, train_labels, test and referenced image files.
train = pd.read_csv(os.path.join(PUBLIC, "train.csv")).merge(pd.read_csv(os.path.join(PUBLIC, "train_labels.csv")), on="case_id")
test = pd.read_csv(os.path.join(PUBLIC, "test.csv"))
test["cands"] = test.candidate_ids.str.split()

_img_cache = {}


def load_img(k):
    if k not in _img_cache:
        _img_cache[k] = Image.open(os.path.join(PUBLIC, "images", f"{k}.jpg")).convert("RGB")
    return _img_cache[k]


def train_pairs(df):
    """gallery -> list of (image_a, image_b) episode pairs from the training answers."""
    out = {}
    for r in df.itertuples():
        out.setdefault(r.gallery, set()).add(tuple(sorted((r.query_id, r.correct_candidate_id))))
    return {g: sorted(v) for g, v in out.items()}


class GalleryDataset(Dataset):
    """One item = one training gallery (subsampled to whole pairs); the model sees every image of the
    gallery together so the negatives are the same-species specimens it must separate at test time."""

    def __init__(self, pairs_by_gallery, tf, max_imgs):
        self.gals = list(pairs_by_gallery); self.pairs = pairs_by_gallery; self.tf = tf; self.max_imgs = max_imgs

    def __len__(self):
        return len(self.gals)

    def __getitem__(self, i):
        pairs = self.pairs[self.gals[i]]
        if len(pairs) * 2 > self.max_imgs:
            pairs = [pairs[j] for j in torch.randperm(len(pairs))[: self.max_imgs // 2].tolist()]
        imgs = [x for p in pairs for x in p]
        partner = torch.arange(len(imgs)) ^ 1
        return torch.stack([self.tf(load_img(k)) for k in imgs]), partner


def collate(batch):
    xs, ps, gid, off = [], [], [], 0
    for g, (x, p) in enumerate(batch):
        xs.append(x); ps.append(p + off); gid.append(torch.full((len(p),), g)); off += len(p)
    return torch.cat(xs), torch.cat(ps), torch.cat(gid)


def param_groups(m):
    nb = len(m.blocks)
    groups = {}
    for n, p in m.named_parameters():
        if n.startswith("blocks."):
            layer = int(n.split(".")[1]) + 1
        elif n.startswith(("patch_embed", "cls_token", "pos_embed", "reg_token")):
            layer = 0
        else:
            layer = nb + 1
        scale = LAYER_DECAY ** (nb + 1 - layer)
        wd = 0.0 if p.ndim == 1 or n.endswith(".bias") else WD
        groups.setdefault((scale, wd), []).append(p)
    return [{"params": ps, "lr": LR * s, "weight_decay": wd} for (s, wd), ps in groups.items()]


def fit_member(name, h, w, seed, tta_scales):
    seed_all(seed)
    model = timm.create_model(name, pretrained=True, num_classes=0, dynamic_img_size=True).to(DEV)
    model.set_grad_checkpointing(True)  # trades ~30% speed for a much smaller activation footprint
    tf_train = T.Compose([T.RandomResizedCrop((h, w), scale=(0.8, 1.0), ratio=(0.68, 0.75)),
                          T.ColorJitter(0.1, 0.1, 0.0, 0.0), T.ToTensor(), T.Normalize(MEAN, STD)])
    ds = GalleryDataset(train_pairs(train), tf_train, MAX_IMGS)
    dl = DataLoader(ds, batch_size=GAL_PER_STEP, shuffle=True, collate_fn=collate, num_workers=6, drop_last=True,
                    persistent_workers=True, generator=torch.Generator().manual_seed(seed))
    opt = torch.optim.AdamW(param_groups(model), lr=LR)
    steps = EPOCHS * len(dl); warm = int(0.1 * steps)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: (s + 1) / warm if s < warm else 0.5 * (1 + math.cos(math.pi * (s - warm) / max(1, steps - warm))))
    model.train()
    for ep in range(EPOCHS):
        tot, nb = 0.0, 0
        for x, partner, gid in dl:
            x, partner, gid = x.to(DEV, non_blocking=True), partner.to(DEV), gid.to(DEV)
            with torch.autocast(DEV, dtype=torch.bfloat16, enabled=DEV == "cuda"):
                f = model(x)
            f = F.normalize(f.float(), dim=-1)
            logits = f @ f.T / TEMP
            # only same-gallery images are candidates; an image is never its own candidate
            mask = (gid[:, None] != gid[None, :]) | torch.eye(len(gid), dtype=torch.bool, device=DEV)
            loss = F.cross_entropy(logits.masked_fill(mask, -1e4), partner)
            opt.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step(); sched.step()
            tot += loss.item(); nb += 1
        print(f"  {name} {h}x{w} seed{seed} epoch {ep + 1}/{EPOCHS} loss {tot / nb:.4f}", flush=True)
    return model, [tta_view(h, w, s) for s in tta_scales]


def tta_view(h, w, s):
    """s == 1: plain resize; s > 1: zoom in (resize then centre crop); s < 1: zoom out (smaller resize)."""
    if s == 1:
        return T.Compose([T.Resize((h, w)), T.ToTensor(), T.Normalize(MEAN, STD)])
    if s > 1:
        return T.Compose([T.Resize((int(h * s), int(w * s))), T.CenterCrop((h, w)), T.ToTensor(), T.Normalize(MEAN, STD)])
    return T.Compose([T.Resize((int(h * s) // 14 * 14, int(w * s) // 14 * 14)), T.ToTensor(), T.Normalize(MEAN, STD)])


@torch.no_grad()
def embed(model, views, keys):
    model.eval(); out = []
    for i in range(0, len(keys), 64):
        acc = 0
        for tf in views:
            x = torch.stack([tf(load_img(k)) for k in keys[i:i + 64]]).to(DEV)
            with torch.autocast(DEV, dtype=torch.bfloat16, enabled=DEV == "cuda"):
                f = model(x)
            acc = acc + F.normalize(f.float(), dim=-1)
        out.append(F.normalize(acc, dim=-1).cpu())
    return torch.cat(out).numpy()


def sinkhorn(S, temp, iters):
    L = S / temp
    np.fill_diagonal(L, -1e9)
    for _ in range(iters):
        L = L - np.logaddexp.reduce(L, axis=1, keepdims=True)
        L = L - np.logaddexp.reduce(L, axis=0, keepdims=True)
    return L


t0 = time.time()
test_keys = sorted(set(test.query_id) | set(x for c in test.cands for x in c))
sims = []
for name, h, w, seed, tta_scales in MEMBERS:
    model, views = fit_member(name, h, w, seed, tta_scales)
    E = embed(model, views, test_keys)
    sims.append(E @ E.T)
    del model; torch.cuda.empty_cache()
    print(f"member done, elapsed {time.time() - t0:.0f}s", flush=True)
S_all = np.mean(sims, axis=0)
kidx = {k: i for i, k in enumerate(test_keys)}

# Per test gallery: average similarity matrix -> Sinkhorn -> rank each query's candidates.
scores = {}
for g, d in test.groupby("gallery"):
    imgs = sorted(set(d.query_id) | set(x for c in d.cands for x in c))
    ii = [kidx[k] for k in imgs]
    L = sinkhorn(S_all[np.ix_(ii, ii)], SINKHORN_TEMP, SINKHORN_ITERS)
    li = {k: i for i, k in enumerate(imgs)}
    scores[g] = (li, L)

rows = []
for r in test.itertuples():
    li, L = scores[r.gallery]
    s = L[li[r.query_id], [li[c] for c in r.cands]]
    order = np.argsort(-s, kind="stable")
    rows.append((r.case_id, " ".join(r.cands[i] for i in order)))
sub = pd.DataFrame(rows, columns=["case_id", "ranked_candidate_ids"])

# structural checks against test.csv before writing
assert len(sub) == len(test) and sub.case_id.is_unique and set(sub.case_id) == set(test.case_id)
for r, c in zip(test.itertuples(), sub.ranked_candidate_ids):
    assert sorted(c.split()) == sorted(r.cands)
os.makedirs(os.path.dirname(os.path.abspath(OUT)), exist_ok=True)
sub.to_csv(OUT, index=False)
print(f"wrote {OUT} ({len(sub)} rows) in {time.time() - t0:.0f}s")
